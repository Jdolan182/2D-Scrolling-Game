package game2D;

public enum Direction {

	
	Left,
	
	Right
}
